// next-sitemap.config.js
module.exports = {
  siteUrl: 'https://www.xn----9sb8ajp.xn--p1ai',
  generateRobotsTxt: false, // мы сами создали robots.txt
  outDir: 'public',
};